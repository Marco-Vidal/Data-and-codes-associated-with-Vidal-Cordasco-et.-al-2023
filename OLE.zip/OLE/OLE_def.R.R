rm(list = ls()) # Clear all
setwd(dirname(rstudioapi::getActiveDocumentContext()$path))
library(openxlsx)
library(sExtinct)
library(rcarbon)
library(ggplot2)
library(gridExtra)
require(Bchron)
library(gridExtra)
library(grid)
library(ggpubr)
### FUNCTIONS TO PERFORM OLE MODELS WITH RESAMPLING PROCEDURE

# Create a data.frame with outputs:

Output_OLE <- data.frame("Region" = c(NA),
                        "Estimate" = c(NA),
                        "lowerCI" = c(NA),
                        "upperCI" = c(NA),
                        "Culture" = c(NA))

# Function to estimate the extinction time from resampling, see the Methods section for details

T_extinction <- function(x) 
{
  Output_TE <- data.frame("Estimate" = c(NA),
                         "lowerCI" = c(NA),
                         "upperCI" = c(NA))
  set.seed(123)
  for(i in 1:10000) {                                          
    n <- 1
    func1 <- function(x) rnorm(n, mean = x[1], sd = x[2])
    df<-apply(Dataset[,2:3], 1, FUN = func1)
    df<-as.data.frame(df)
    df <- df[with(df, order(-df)), ]
    df<-as.data.frame(df * -1)
    names(df)[names(df) == "df"] <- "years"
    df$sightings<-1
    OLE<-OLE.fun(df, alpha=0.05) #### alpha is 0.1 because it is divided by 2, so the real alpha is 0.05
    Output_TE[nrow(Output_TE) + 1,] <- c(OLE$Estimate, OLE$lowerCI, OLE$upperCI)
    Output_OLE[nrow(Output_OLE) + 1,] <- c(Region, OLE$Estimate, OLE$lowerCI, OLE$upperCI, Culture)
    
  }
  print(mean(Output_TE$Estimate, na.rm=TRUE))
  print(mean(Output_TE$lowerCI, na.rm=TRUE))
  print(mean(Output_TE$upperCI, na.rm=TRUE))
  
  write.xlsx(Output_OLE, "Output_OLE_MP.xlsx")
}

# Function to estimate the origin time from resampling

T_origin <- function(x) 
{
  Output_O <- data.frame("Estimate" = c(NA),
                         "lowerCI" = c(NA),
                         "upperCI" = c(NA))
  
  set.seed(123)
  for(i in 1:10000) {                                          
    n <- 1
    func1 <- function(x) rnorm(n, mean = x[1], sd = x[2])
    df<-apply(Dataset[,2:3], 1, FUN = func1)
    df<-as.data.frame(df)
    df <- df[with(df, order(-df)), ]
    df<-as.data.frame(df)
    names(df)[names(df) == "df"] <- "years"
    df$sightings<-1
    OLE<-OLE.fun(df, alpha=0.05)
    Output_O[nrow(Output_O) + 1,] <- c(OLE$Estimate, OLE$lowerCI, OLE$upperCI)
    Output_OLE[nrow(Output_OLE) + 1,] <- c(Region, OLE$Estimate, OLE$lowerCI, OLE$upperCI, Culture)
    
  }
  
  print(mean(Output_O$Estimate, na.rm=TRUE))
  print(mean(Output_O$lowerCI, na.rm=TRUE))
  print(mean(Output_O$upperCI, na.rm=TRUE))

  write.xlsx(Output_OLE, "Output_OLE_EUP.xlsx")
}


#OPTIMAL LINEAR ESTIMATION


##############################################
################
###  R_1
###############
##############################################

Region<- "R_1"
Culture<- "MP"

DF<- readRDS("OLE.rds")


Dataset<- subset(DF, Culture=="MP" & Region=="R_1")
Dataset


CRE_Dataset<- as.data.frame(Dataset$Cal.Age.BP * -1)
CRE_Dataset <- CRE_Dataset[with(CRE_Dataset, order(-CRE_Dataset)), ]
CRE_Dataset<- as.data.frame(CRE_Dataset)
CRE_Dataset$sightings<-1
CRE_Dataset

OLE.fun(CRE_Dataset, alpha=0.05) 

# Resampling:

T_extinction()



## DANUBIAN REGION, START IUP
Region<- "R_1"
Culture<- "EUP"

Dataset<- subset(DF, Culture=="EUP" & Region=="R_1")
Dataset

#Central Range Estimate:
CRE_Dataset<- as.data.frame(Dataset$Cal.Age.BP)
CRE_Dataset <- CRE_Dataset[with(CRE_Dataset, order(-CRE_Dataset)), ]
CRE_Dataset<- as.data.frame(CRE_Dataset)
CRE_Dataset$sightings<-1
CRE_Dataset
OLE.fun(CRE_Dataset, alpha=0.05)

# Resampling:
T_origin()



##############################################
################
###  R_2
###############
##############################################
Region<- "R_2"
Culture<- "MP"

Dataset<- subset(DF, Culture=="MP" & Region=="R_2")


CRE_Dataset<- as.data.frame(Dataset$Cal.Age.BP * -1)
CRE_Dataset <- CRE_Dataset[with(CRE_Dataset, order(-CRE_Dataset)), ]
CRE_Dataset<- as.data.frame(CRE_Dataset)
CRE_Dataset$sightings<-1
CRE_Dataset

OLE.fun(CRE_Dataset, alpha=0.05) 

# Resampling:

T_extinction()


## R_2, START EUP
Region<- "R_2"
Culture<- "EUP"
Dataset<- subset(DF, Culture=="EUP" & Region=="R_2")
Dataset

#Central Range Estimate:
CRE_Dataset<- as.data.frame(Dataset$Cal.Age.BP)
CRE_Dataset <- CRE_Dataset[with(CRE_Dataset, order(-CRE_Dataset)), ]
CRE_Dataset<- as.data.frame(CRE_Dataset)
CRE_Dataset$sightings<-1
CRE_Dataset
OLE.fun(CRE_Dataset, alpha=0.05)

# Resampling:
T_origin()

##############################################
################
###  R_3
###############
##############################################


## In R_3, the number of chronometric determination with MP is < 5
#Dataset<- subset(DF, Culture=="MP" & Region=="R_3")
#CRE_Dataset<- as.data.frame(Dataset$Cal.Age.BP * -1)
#CRE_Dataset <- CRE_Dataset[with(CRE_Dataset, order(-CRE_Dataset)), ]
#CRE_Dataset<- as.data.frame(CRE_Dataset)
#CRE_Dataset$sightings<-1
#CRE_Dataset

#OLE.fun(CRE_Dataset, alpha=0.05) 

# Resampling:

#T_extinction()


## Start EUP
Region<- "R_3"
Culture<- "EUP"
Dataset<- subset(DF, Culture=="EUP" & Region=="R_3")
Dataset

#Central Range Estimate:
CRE_Dataset<- as.data.frame(Dataset$Cal.Age.BP)
CRE_Dataset <- CRE_Dataset[with(CRE_Dataset, order(-CRE_Dataset)), ]
CRE_Dataset<- as.data.frame(CRE_Dataset)
CRE_Dataset$sightings<-1
CRE_Dataset
OLE.fun(CRE_Dataset, alpha=0.05)

# Resampling:
T_origin()


##############################################
################
###  R_4
###############
##############################################

Region<- "R_4"
Culture<- "MP"
Dataset<- subset(DF, Culture=="MP" & Region=="R_4")


CRE_Dataset<- as.data.frame(Dataset$Cal.Age.BP * -1)
CRE_Dataset <- CRE_Dataset[with(CRE_Dataset, order(-CRE_Dataset)), ]
CRE_Dataset<- as.data.frame(CRE_Dataset)
CRE_Dataset$sightings<-1
CRE_Dataset

OLE.fun(CRE_Dataset, alpha=0.05) 

# Resampling:

T_extinction()


## R_4, START EUP
Region<- "R_4"
Culture<- "EUP"
Dataset<- subset(DF, Culture=="EUP" & Region=="R_4")
Dataset

#Central Range Estimate:
CRE_Dataset<- as.data.frame(Dataset$Cal.Age.BP)
CRE_Dataset <- CRE_Dataset[with(CRE_Dataset, order(-CRE_Dataset)), ]
CRE_Dataset<- as.data.frame(CRE_Dataset)
CRE_Dataset$sightings<-1
CRE_Dataset
OLE.fun(CRE_Dataset, alpha=0.05)

# Resampling:
T_origin()


##############################################
################
###  R_5
###############
##############################################
Region<- "R_5"
Culture<- "MP"

Dataset<- subset(DF, Culture=="MP" & Region=="R_5")


CRE_Dataset<- as.data.frame(Dataset$Cal.Age.BP * -1)
CRE_Dataset <- CRE_Dataset[with(CRE_Dataset, order(-CRE_Dataset)), ]
CRE_Dataset<- as.data.frame(CRE_Dataset)
CRE_Dataset$sightings<-1
CRE_Dataset

OLE.fun(CRE_Dataset, alpha=0.05) 

# Resampling:

T_extinction()


## R_5, START EUP
Region<- "R_5"
Culture<- "EUP"
Dataset<- subset(DF, Culture=="EUP" & Region=="R_5")
Dataset

#Central Range Estimate:
CRE_Dataset<- as.data.frame(Dataset$Cal.Age.BP)
CRE_Dataset <- CRE_Dataset[with(CRE_Dataset, order(-CRE_Dataset)), ]
CRE_Dataset<- as.data.frame(CRE_Dataset)
CRE_Dataset$sightings<-1
CRE_Dataset
OLE.fun(CRE_Dataset, alpha=0.05)

# Resampling:
T_origin()

##############################################
################
###  R_6
###############
##############################################
Region<- "R_6"
Culture<- "MP"

Dataset<- subset(DF, Culture=="MP" & Region=="R_6")


CRE_Dataset<- as.data.frame(Dataset$Cal.Age.BP * -1)
CRE_Dataset <- CRE_Dataset[with(CRE_Dataset, order(-CRE_Dataset)), ]
CRE_Dataset<- as.data.frame(CRE_Dataset)
CRE_Dataset$sightings<-1
CRE_Dataset

OLE.fun(CRE_Dataset, alpha=0.05) 

# Resampling:

T_extinction()

##############################################
################
###  R_7
###############
##############################################
Region<- "R_7"
Culture<- "MP"

Dataset<- subset(DF, Culture=="MP" & Region=="R_7")


CRE_Dataset<- as.data.frame(Dataset$Cal.Age.BP * -1)
CRE_Dataset <- CRE_Dataset[with(CRE_Dataset, order(-CRE_Dataset)), ]
CRE_Dataset<- as.data.frame(CRE_Dataset)
CRE_Dataset$sightings<-1
CRE_Dataset

OLE.fun(CRE_Dataset, alpha=0.05) 

# Resampling:

T_extinction()


## R_7, START EUP
Region<- "R_7"
Culture<- "EUP"
Dataset<- subset(DF, Culture=="EUP" & Region=="R_7")
Dataset

#Central Range Estimate:
CRE_Dataset<- as.data.frame(Dataset$Cal.Age.BP)
CRE_Dataset <- CRE_Dataset[with(CRE_Dataset, order(-CRE_Dataset)), ]
CRE_Dataset<- as.data.frame(CRE_Dataset)
CRE_Dataset$sightings<-1
CRE_Dataset
OLE.fun(CRE_Dataset, alpha=0.05)

# Resampling:
T_origin()


##############################################
################
###  R_8
###############
##############################################
Region<- "R_8"
Culture<- "MP"

Dataset<- subset(DF, Culture=="MP" & Region=="R_8")


CRE_Dataset<- as.data.frame(Dataset$Cal.Age.BP * -1)
CRE_Dataset <- CRE_Dataset[with(CRE_Dataset, order(-CRE_Dataset)), ]
CRE_Dataset<- as.data.frame(CRE_Dataset)
CRE_Dataset$sightings<-1
CRE_Dataset

OLE.fun(CRE_Dataset, alpha=0.05) 

# Resampling:

T_extinction()


## R_8, START EUP
Region<- "R_8"
Culture<- "EUP"
Dataset<- subset(DF, Culture=="EUP" & Region=="R_8")
Dataset

#Central Range Estimate:
CRE_Dataset<- as.data.frame(Dataset$Cal.Age.BP)
CRE_Dataset <- CRE_Dataset[with(CRE_Dataset, order(-CRE_Dataset)), ]
CRE_Dataset<- as.data.frame(CRE_Dataset)
CRE_Dataset$sightings<-1
CRE_Dataset
OLE.fun(CRE_Dataset, alpha=0.05)

# Resampling:
T_origin()

##############################################
################
###  R_9
###############
##############################################
Region<- "R_9"
Culture<- "MP"

Dataset<- subset(DF, Culture=="MP" & Region=="R_9")


CRE_Dataset<- as.data.frame(Dataset$Cal.Age.BP * -1)
CRE_Dataset <- CRE_Dataset[with(CRE_Dataset, order(-CRE_Dataset)), ]
CRE_Dataset<- as.data.frame(CRE_Dataset)
CRE_Dataset$sightings<-1
CRE_Dataset

OLE.fun(CRE_Dataset, alpha=0.05) 

# Resampling:

T_extinction()


## R_9, START EUP
Region<- "R_9"
Culture<- "EUP"
Dataset<- subset(DF, Culture=="EUP" & Region=="R_9")
Dataset

#Central Range Estimate:
CRE_Dataset<- as.data.frame(Dataset$Cal.Age.BP)
CRE_Dataset <- CRE_Dataset[with(CRE_Dataset, order(-CRE_Dataset)), ]
CRE_Dataset<- as.data.frame(CRE_Dataset)
CRE_Dataset$sightings<-1
CRE_Dataset
OLE.fun(CRE_Dataset, alpha=0.05)

# Resampling:
T_origin()
##############################################
################
###  R_10
###############
##############################################
Region<- "R_10"
Culture<- "MP"

Dataset<- subset(DF, Culture=="MP" & Region=="R_10")


CRE_Dataset<- as.data.frame(Dataset$Cal.Age.BP * -1)
CRE_Dataset <- CRE_Dataset[with(CRE_Dataset, order(-CRE_Dataset)), ]
CRE_Dataset<- as.data.frame(CRE_Dataset)
CRE_Dataset$sightings<-1
CRE_Dataset

OLE.fun(CRE_Dataset, alpha=0.05) 

# Resampling:

T_extinction()


## R_10, START EUP
Region<- "R_10"
Culture<- "EUP"
Dataset<- subset(DF, Culture=="EUP" & Region=="R_10")
Dataset

#Central Range Estimate:
CRE_Dataset<- as.data.frame(Dataset$Cal.Age.BP)
CRE_Dataset <- CRE_Dataset[with(CRE_Dataset, order(-CRE_Dataset)), ]
CRE_Dataset<- as.data.frame(CRE_Dataset)
CRE_Dataset$sightings<-1
CRE_Dataset
OLE.fun(CRE_Dataset, alpha=0.05)

# Resampling:
T_origin()
##############################################
################
###  R_11
###############
##############################################
Region<- "R_11"
Culture<- "MP"

Dataset<- subset(DF, Culture=="MP" & Region=="R_11")


CRE_Dataset<- as.data.frame(Dataset$Cal.Age.BP * -1)
CRE_Dataset <- CRE_Dataset[with(CRE_Dataset, order(-CRE_Dataset)), ]
CRE_Dataset<- as.data.frame(CRE_Dataset)
CRE_Dataset$sightings<-1
CRE_Dataset

OLE.fun(CRE_Dataset, alpha=0.05) 

# Resampling:

T_extinction()


## R_11, START EUP
Region<- "R_11"
Culture<- "EUP"
Dataset<- subset(DF, Culture=="EUP" & Region=="R_11")
Dataset

#Central Range Estimate:
CRE_Dataset<- as.data.frame(Dataset$Cal.Age.BP)
CRE_Dataset <- CRE_Dataset[with(CRE_Dataset, order(-CRE_Dataset)), ]
CRE_Dataset<- as.data.frame(CRE_Dataset)
CRE_Dataset$sightings<-1
CRE_Dataset
OLE.fun(CRE_Dataset, alpha=0.05)

# Resampling:
T_origin()
##############################################
################
###  R_12
###############
##############################################
Region<- "R_12"
Culture<- "MP"

Dataset<- subset(DF, Culture=="MP" & Region=="R_12")


CRE_Dataset<- as.data.frame(Dataset$Cal.Age.BP * -1)
CRE_Dataset <- CRE_Dataset[with(CRE_Dataset, order(-CRE_Dataset)), ]
CRE_Dataset<- as.data.frame(CRE_Dataset)
CRE_Dataset$sightings<-1
CRE_Dataset

OLE.fun(CRE_Dataset, alpha=0.05) 

# Resampling:

T_extinction()


## R_12, START EUP
Region<- "R_12"
Culture<- "EUP"
Dataset<- subset(DF, Culture=="EUP" & Region=="R_12")
Dataset

#Central Range Estimate:
CRE_Dataset<- as.data.frame(Dataset$Cal.Age.BP)
CRE_Dataset <- CRE_Dataset[with(CRE_Dataset, order(-CRE_Dataset)), ]
CRE_Dataset<- as.data.frame(CRE_Dataset)
CRE_Dataset$sightings<-1
CRE_Dataset
OLE.fun(CRE_Dataset, alpha=0.05)

# Resampling:
T_origin()
##############################################
################
###  R_13
###############
##############################################
Region<- "R_13"
Culture<- "MP"

Dataset<- subset(DF, Culture=="MP" & Region=="R_13")


CRE_Dataset<- as.data.frame(Dataset$Cal.Age.BP * -1)
CRE_Dataset <- CRE_Dataset[with(CRE_Dataset, order(-CRE_Dataset)), ]
CRE_Dataset<- as.data.frame(CRE_Dataset)
CRE_Dataset$sightings<-1
CRE_Dataset

OLE.fun(CRE_Dataset, alpha=0.05) 

# Resampling:

T_extinction()


##############################################
################
###  R_14
###############
##############################################
Region<- "R_14"
Culture<- "MP"

Dataset<- subset(DF, Culture=="MP" & Region=="R_14")


CRE_Dataset<- as.data.frame(Dataset$Cal.Age.BP * -1)
CRE_Dataset <- CRE_Dataset[with(CRE_Dataset, order(-CRE_Dataset)), ]
CRE_Dataset<- as.data.frame(CRE_Dataset)
CRE_Dataset$sightings<-1
CRE_Dataset

OLE.fun(CRE_Dataset, alpha=0.05) 

# Resampling:

T_extinction()


## R_14, START EUP
Region<- "R_14"
Culture<- "EUP"
Dataset<- subset(DF, Culture=="EUP" & Region=="R_14")
Dataset

#Central Range Estimate:
CRE_Dataset<- as.data.frame(Dataset$Cal.Age.BP)
CRE_Dataset <- CRE_Dataset[with(CRE_Dataset, order(-CRE_Dataset)), ]
CRE_Dataset<- as.data.frame(CRE_Dataset)
CRE_Dataset$sightings<-1
CRE_Dataset
OLE.fun(CRE_Dataset, alpha=0.05)

# Resampling:
T_origin()
##############################################
################
###  R_15
###############
##############################################
Region<- "R_15"
Culture<- "MP"

Dataset<- subset(DF, Culture=="MP" & Region=="R_15")


CRE_Dataset<- as.data.frame(Dataset$Cal.Age.BP * -1)
CRE_Dataset <- CRE_Dataset[with(CRE_Dataset, order(-CRE_Dataset)), ]
CRE_Dataset<- as.data.frame(CRE_Dataset)
CRE_Dataset$sightings<-1
CRE_Dataset

OLE.fun(CRE_Dataset, alpha=0.05) 

# Resampling:

T_extinction()


## R_15, START EUP
Region<- "R_15"
Culture<- "EUP"
Dataset<- subset(DF, Culture=="EUP" & Region=="R_15")
Dataset

#Central Range Estimate:
CRE_Dataset<- as.data.frame(Dataset$Cal.Age.BP)
CRE_Dataset <- CRE_Dataset[with(CRE_Dataset, order(-CRE_Dataset)), ]
CRE_Dataset<- as.data.frame(CRE_Dataset)
CRE_Dataset$sightings<-1
CRE_Dataset
OLE.fun(CRE_Dataset, alpha=0.05)

# Resampling:
T_origin()
##############################################
################
###  R_16
###############
##############################################
Region<- "R_16"
Culture<- "MP"

Dataset<- subset(DF, Culture=="MP" & Region=="R_16")


CRE_Dataset<- as.data.frame(Dataset$Cal.Age.BP * -1)
CRE_Dataset <- CRE_Dataset[with(CRE_Dataset, order(-CRE_Dataset)), ]
CRE_Dataset<- as.data.frame(CRE_Dataset)
CRE_Dataset$sightings<-1
CRE_Dataset

OLE.fun(CRE_Dataset, alpha=0.05) 

# Resampling:

T_extinction()


## R_16, START EUP
Region<- "R_16"
Culture<- "EUP"
Dataset<- subset(DF, Culture=="EUP" & Region=="R_16")
Dataset

#Central Range Estimate:
CRE_Dataset<- as.data.frame(Dataset$Cal.Age.BP)
CRE_Dataset <- CRE_Dataset[with(CRE_Dataset, order(-CRE_Dataset)), ]
CRE_Dataset<- as.data.frame(CRE_Dataset)
CRE_Dataset$sightings<-1
CRE_Dataset
OLE.fun(CRE_Dataset, alpha=0.05)

# Resampling:
T_origin()


#####################################
#
# RESULTS
#

# Load Dataset with OLE outputs
OLE_DF<- read.xlsx("Output_OLE_All.xlsx", rowNames= FALSE, colNames= TRUE, sheet="Hoja1")
head(OLE_DF)


dodge <- position_dodge(width = 0.9)


EUP_df <- subset(OLE_DF, Culture=="EUP")

Plot_EUP<- ggplot(data= EUP_df, aes(x=Region, y=Estimate, fill=Culture)) +
   scale_x_discrete(limits=c("R_16", "R_15", "R_14", "R_13", "R_12", "R_11", "R_10", "R_9", "R_8", "R_7",
                             "R_6", "R_5", "R_4", "R_3", "R_2", "R_1"))+
  geom_violin( color="Red") +
  stat_summary(fun.data=mean_sdl, 
                 geom="pointrange", color="black",position = dodge)+
#  scale_fill_manual(values=alpha("Red"), 0.5)+
 # geom_point(data = BAM_DF, aes(x=factor(Region), y=Age_M, fill=Culture, color=Culture))+
 # geom_errorbar( aes(ymax = BAM_DF$`95_UL_M`, ymin = BAM_DF$`95_LL_M`))+
  theme_classic() +
 scale_y_reverse(limits= c(60000, 25000), breaks = seq(20000, 65000, 5000)) +
  xlab("") +
  ylab("cal age BP")+
coord_flip()+
theme(legend.position = "none")+
  ggtitle("Optimal linear estimation") +
  theme(plot.title = element_text(hjust = 0.5))
Plot_EUP

MP_df <- subset(OLE_DF, Culture=="MP")

Plot_MP<- ggplot(data= MP_df, aes(x=Region, y=Estimate, fill=Culture)) +
  scale_x_discrete(limits=c("R_16", "R_15", "R_14", "R_13", "R_12", "R_11", "R_10", "R_9", "R_8", "R_7",
                            "R_6", "R_5", "R_4", "R_3", "R_2", "R_1"))+
  geom_violin() +
  stat_summary(fun.data=mean_sdl, 
               geom="pointrange", color="black",position = dodge)+
  scale_fill_manual(values=alpha("skyblue1"), )+
  # geom_point(data = BAM_DF, aes(x=factor(Region), y=Age_M, fill=Culture, color=Culture))+
  # geom_errorbar( aes(ymax = BAM_DF$`95_UL_M`, ymin = BAM_DF$`95_LL_M`))+
  theme_classic() +
  scale_y_reverse(limits= c(60000, 25000), breaks = seq(20000, 65000, 5000)) +
  xlab("") +
  ylab("cal age BP")+
  coord_flip()+ theme(legend.position = "none")+
  ggtitle("Optimal linear estimation") +
  theme(plot.title = element_text(hjust = 0.5))
Plot_MP


BAM_DF <-read.xlsx("Output_OLE_All.xlsx", rowNames= FALSE, colNames= TRUE, sheet="BAM")
head(BAM_DF)

EUP_df <- subset(BAM_DF, Culture=="EUP")

PlotB_EUP<- ggplot(data= EUP_df, aes(x=factor(Region), y=Age_M)) +
  scale_x_discrete(limits=c("R_16", "R_15", "R_14", "R_13", "R_12", "R_11", "R_10", "R_9", "R_8", "R_7",
                            "R_6", "R_5", "R_4", "R_3", "R_2", "R_1"))+
  #geom_violin(position = dodge) +
  geom_point()+
  geom_errorbar(aes(ymax = `95_UL_M`, ymin = `95_LL_M`), col="Red")+
  scale_color_manual(values=alpha(c("blue4", "firebrick4"), 0.5))+
  theme_classic() +
  scale_y_reverse(limits= c(60000, 25000), breaks = seq(20000, 65000, 5000)) +
  xlab("") +
  ylab("cal age BP")+
  coord_flip()+ theme(legend.position = "none")+
  ggtitle("Bayesian age model") +
  theme(plot.title = element_text(hjust = 0.5))


PlotB_EUP

MP_df <- subset(BAM_DF, Culture=="MP")

PlotB_MP<- ggplot(data= MP_df, aes(x=factor(Region), y=Age_M, fill=Culture, color="Blue")) +
  scale_x_discrete(limits=c("R_16", "R_15", "R_14", "R_13", "R_12", "R_11", "R_10", "R_9", "R_8", "R_7",
                            "R_6", "R_5", "R_4", "R_3", "R_2", "R_1"))+
  #geom_violin(position = dodge) +
  geom_point()+
  geom_errorbar(aes(ymax = `95_UL_M`, ymin = `95_LL_M`))+
  scale_color_manual(values=alpha("skyblue1"), )+
  theme_classic() +
  scale_y_reverse(limits= c(60000, 25000), breaks = seq(20000, 65000, 5000)) +
  xlab("") +
  ylab("cal age BP")+
  coord_flip()+ theme(legend.position = "none")+
  ggtitle("Bayesian age model") +
  theme(plot.title = element_text(hjust = 0.5))

PlotB_MP


### Correlation between outputs obtained from OLE and BAM models:

Dataset <- read.xlsx("Output_OLE_ALL.xlsx", rowNames=FALSE,
                      colNames=TRUE, sheet="OLE")
head(Dataset)


BAM_OLE_N <- ggplot(data=Dataset, aes(x=Neand_Dissap, y=Neand_Dissap_BAM, label=Region))+
  geom_point() + 
  geom_text(hjust=0.5, vjust=-0.9)+
  geom_smooth(method=lm , se=TRUE)+
  # geom_errorbar(aes(ymin = Sapiens_App - (Sapiens_App_SD*2) , ymax = Sapiens_App + (Sapiens_App_SD*2)), alpha=0.3) + 
  #  geom_errorbarh(aes(xmin =Large - (Large_SD* 2), xmax = Large + (Large_SD* 2)), alpha=0.3)+
  xlab("OLE MP dissapearance")+
  ylab("BAM MP dissapearance")+
  # stat_cor(method="pearson")+
  theme_classic()


BAM_OLE_N


BAM_OLE_S <- ggplot(data=Dataset, aes(x=Sapiens_App, y=Sapiens_App_BAM, label=Region))+
  geom_point() + 
  geom_text(hjust=0.5, vjust=-0.9)+
  geom_smooth(method=lm , se=TRUE)+
  xlab("OLE EUP appearance")+
  ylab("BAM EUP appearance")+
  # stat_cor(method="pearson")+
  theme_classic()


BAM_OLE_S

# Plot results
grid.arrange(Plot_MP, Plot_EUP, PlotB_MP,  PlotB_EUP,BAM_OLE_N, BAM_OLE_S, ncol=2)


# Association between OLE and BAM models with the ecosystems' productivity:

DatasetC <- read.xlsx("Output_OLE_ALL.xlsx", rowNames=FALSE,
                     colNames=TRUE, sheet="OLE&BAM")
head(DatasetC)

BAM_OLE_NPP_N <- ggplot(data=DatasetC, aes(x=NPP, y=Neand_Dissap, group=Model, color=Model))+
  geom_point() + 
  geom_smooth(method=lm , se=FALSE)+
  xlab((expression(paste("NPP (kg/m"^2, '/yr)'))))+
  ylab("MP disappearance (cal age BP)")+
  scale_y_reverse()+
  # stat_cor(method="pearson")+
  stat_cor(method = "pearson")+
  theme_classic()


BAM_OLE_NPP_N

BAM_OLE_NPP_S <- ggplot(data=DatasetC, aes(x=NPP, y=Sapiens_App, group=Model, color=Model))+
  geom_point() + 
  geom_smooth(method=lm , se=FALSE)+
  xlab((expression(paste("NPP (kg/m"^2, '/yr)'))))+
  ylab("EUP appearance (cal age BP)")+
  scale_y_reverse()+
  # stat_cor(method="pearson")+
  stat_cor(method = "pearson")+
  theme_classic()

BAM_OLE_NPP_S

#Small
BAM_OLE_Small_N <- ggplot(data=DatasetC, aes(x=Small, y=Neand_Dissap, group=Model, color=Model))+
  geom_point() + 
  geom_smooth(method=lm , se=FALSE)+
  xlab((expression(paste("CC Small (kg/km"^2, '/yr)'))))+
  ylab("MP disappearance (cal age BP)")+
  scale_y_reverse()+
  # stat_cor(method="pearson")+
  stat_cor(method = "pearson")+
  theme_classic()


BAM_OLE_Small_N

BAM_OLE_Small_S <- ggplot(data=DatasetC, aes(x=Small, y=Sapiens_App, group=Model, color=Model))+
  geom_point() + 
  geom_smooth(method=lm , se=FALSE)+
  xlab((expression(paste("CC Small (kg/km"^2, '/yr)'))))+
  ylab("EUP appearance (cal age BP)")+
  scale_y_reverse()+
  stat_cor(method="pearson")+
  theme_classic()

BAM_OLE_Small_S

#Medium
BAM_OLE_Medium_N <- ggplot(data=DatasetC, aes(x=Medium, y=Neand_Dissap, group=Model, color=Model))+
  geom_point() + 
  geom_smooth(method=lm , se=FALSE)+
  xlab((expression(paste("CC Medium (kg/km"^2, '/yr)'))))+
  ylab("MP disappearance (cal age BP)")+
  scale_y_reverse()+
   stat_cor(method="pearson")+
  theme_classic()


BAM_OLE_Medium_N

BAM_OLE_Medium_S <- ggplot(data=DatasetC, aes(x=Medium, y=Sapiens_App, group=Model, color=Model))+
  geom_point() + 
  geom_smooth(method=lm , se=FALSE)+
  xlab((expression(paste("CC Medium (kg/km"^2, '/yr)'))))+
  ylab("EUP appearance (cal age BP)")+
  scale_y_reverse()+
  stat_cor(method="pearson")+
  theme_classic()

BAM_OLE_Medium_S
#Large
BAM_OLE_Large_N <- ggplot(data=DatasetC, aes(x=Large, y=Neand_Dissap, group=Model, color=Model))+
  geom_point() + 
  geom_smooth(method=lm , se=FALSE)+
  xlab((expression(paste("CC Large (kg/km"^2, '/yr)'))))+
  ylab("MP disappearance (cal age BP)")+
  scale_y_reverse()+
  stat_cor(method="pearson")+
  theme_classic()


BAM_OLE_Large_N

BAM_OLE_Large_S <- ggplot(data=DatasetC, aes(x=Large, y=Sapiens_App, group=Model, color=Model))+
  geom_point() + 
  geom_smooth(method=lm , se=FALSE)+
  xlab((expression(paste("CC Large (kg/km"^2, '/yr)'))))+
  ylab("EUP appearance (cal age BP)")+
  scale_y_reverse()+
   stat_cor(method="pearson")+
  theme_classic()

BAM_OLE_Large_S

grid.arrange(BAM_OLE_NPP_N, BAM_OLE_NPP_S, BAM_OLE_Small_N, BAM_OLE_Small_S,
             BAM_OLE_Medium_N, BAM_OLE_Medium_S, BAM_OLE_Large_N, BAM_OLE_Large_S, ncol=2)
